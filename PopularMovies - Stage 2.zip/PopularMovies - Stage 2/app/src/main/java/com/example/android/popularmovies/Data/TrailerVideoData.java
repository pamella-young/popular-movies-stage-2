package com.example.android.popularmovies.Data;

/**
 * Created by Pamella on 21-Jul-17.
 */

public class TrailerVideoData {
    private String id;
    private String key;
    private String name;

    public String getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setName(String name) {
        this.name = name;
    }
}
